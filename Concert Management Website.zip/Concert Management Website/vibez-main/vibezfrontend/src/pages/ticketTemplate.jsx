

const TicketTemplate = ()=> {
    return (
        <div className="ticketTemplateContainer">
            <div className="ticketHeader">
                
            </div>

            <div className="ticketBody">

            </div>

            <div className="ticketFooter">

            </div>
        </div>
    )
}

export default TicketTemplate