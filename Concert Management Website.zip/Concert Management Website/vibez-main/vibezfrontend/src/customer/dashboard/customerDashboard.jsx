
const CustomerDashboard = ()=>{

    return (
        <>
            <h3>Customer's Dashboard</h3>
        </>
    )
}

export default CustomerDashboard