This is a full stack concert management website.

This is a MERN stack project.

This website preview video link - 